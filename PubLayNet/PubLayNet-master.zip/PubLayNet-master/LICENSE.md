The annotations in this dataset belong to IBM and are licensed under a [Community Data License Agreement – Permissive – Version 1.0 License](https://cdla.io/permissive-1-0/).

## Images
IBM does not own the copyright of the images. Use of the images must abide by the [PMC Open Access Subset Terms of Use](https://www.ncbi.nlm.nih.gov/pmc/tools/openftlist/). 


